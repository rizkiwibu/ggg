const fetch = require('node-fetch');

const plugin = {
  commands: ['/myip'],
  tags: ['tools'],
  init: async (bot, { mess, api }) => {
    bot.onText(/^\/myip$/, async (msg) => {
      const chatId = msg.chat.id;
      bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });
      try {
        const apis = await fetch('https://api.ipify.org');
        const ip = await apis.text();
        bot.sendMessage(chatId, `Your IP is ${ip}`, { reply_to_message_id: msg.message_id });
      } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, 'An error occurred while processing your request.', { reply_to_message_id: msg.message_id });
      }
    });
  },
};

module.exports = plugin;