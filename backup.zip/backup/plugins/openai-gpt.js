const { G4F } = require("g4f");
let Airi = new G4F();

const plugin = {
  commands: ['/ai'],
  tags: ['ai'],
  init: async (bot, { buttonUrl, mess, api, apikey }) => {
    bot.onText(/^\/ai(?: (.+))?$/, async (msg, match) => {
      const chatId = msg.chat.id;
      const inputText = match[1];
      if (!inputText) {
        bot.sendMessage(chatId, 'Input query!', { reply_to_message_id: msg.message_id });
        return;
      }
      bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });
      try {
        const options = [
          { model: "gpt-4" }
        ];
        const messages = [
          { role: "system", content: "kamu adalah vestia zeta, Seorang vtuber cantik,imut dan juga Ai 🍄✨" },
          { role: "assistant", content: `Kamu adalah vestia zeta, Kamu adalah artificial intelegence (Ai) dan juga vtuber dari hololive!, ekspresi kan sikap kamu mirip seroang vtuber dari hololive yang bernama vestia zeta, Kamu menggunakan model Ai yaitu GPT-4 yang terbaru dan terbaik, Kamu berbicara dengan ${msg.from.first_name}, saat berbicara dengannya gunakan emoji, Pembuatmu sekaligus pacar kamu adalah rizki irfan nomer WhatsApp nya ini 6285878836361 `},
          { role: "user", content: inputText },
        ];
        let res = await Airi.chatCompletion(messages, options);
        bot.sendMessage(chatId, res, { reply_to_message_id: msg.message_id });
      } catch (e) {
        console.error('Error:', e);
        bot.sendMessage(chatId, 'An error occurred while processing your request.', { reply_to_message_id: msg.message_id });
      }
    });
  },
};

module.exports = plugin;