const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

const plugin = {
  commands: ['/ssweb'],
  tags: ['screenshot'],
  init: async (bot, { conn, mess }) => {
    bot.onText(/^\/ssweb(?: (.+))?$/, async (msg, match) => {
      const chatId = msg.chat.id;
      if (!match[1]) {
        return bot.sendMessage(chatId, 'Input URL!', { reply_to_message_id: msg.message_id });
      }

      const args = match[1].trim().split(' ');
      if (!args[0]) {
        return bot.sendMessage(chatId, 'Input URL!', { reply_to_message_id: msg.message_id });
      }

      if (args[0].match(/aduh\.com|hore\.com|poi\.care/i)) {
        return bot.sendMessage(chatId, 'Link tersebut dilarang!', { reply_to_message_id: msg.message_id });
      }

      await bot.sendMessage(chatId, '_Ｌｏａｄｉｎｇ．．._', { reply_to_message_id: msg.message_id });

      const url = args[0].startsWith('http') ? args[0] : 'https://' + args[0];

      try {
        const imgResponse = await fetch(`https://skizo.tech/api/ssweb?apikey=Ikyskizo&url=${url}`);
        if (!imgResponse) {
          await bot.sendMessage(chatId, 'Gagal saat percobaan pertama. Memulai percobaan kedua...', { reply_to_message_id: msg.message_id });
          imgResponse = await fetch(`https://skizo.tech/api/ssweb?type=desktop&url=${url}&apikey=Ikyskizo`);
          if (!imgResponse) {
            return bot.sendMessage(chatId, 'Gambar tidak tersedia', { reply_to_message_id: msg.message_id });
          }
        }

        const filepath = path.join(__dirname, '../tmp/') + (+new Date) + '.jpeg';
        if (!fs.existsSync(path.join(__dirname, '../tmp/'))) {
          fs.mkdirSync(path.join(__dirname, '../tmp/'));
        }

        const dest = fs.createWriteStream(filepath);
        dest.on('finish', () => {
          bot.sendPhoto(chatId, filepath, { caption: 'Nih gambarnya.', reply_to_message_id: msg.message_id });
        });
        imgResponse.body.pipe(dest);
      } catch (e) {
        console.log(e);
        bot.sendMessage(chatId, `Terjadi error!`, { reply_to_message_id: msg.message_id });
      }
    });
  },
};

module.exports = plugin;