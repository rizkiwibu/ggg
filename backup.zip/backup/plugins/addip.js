const axios = require('axios');
const Buffer = require('buffer').Buffer;

const ownerUsernames = ['Ikystoreofficial']; // Tambahkan username pemilik di sini

const plugin = {
  commands: ['/addip'],
  tags: ['ip'],
  init: async (bot, { api, apikey }) => {
    bot.onText(/^\/addip(?: (.+))?$/, async (msg, match) => {
      const chatId = msg.chat.id;
      const username = msg.from.username;

      // Cek apakah pengguna adalah pemilik
      if (!ownerUsernames.includes(username)) {
        bot.sendMessage(chatId, 'Maaf, perintah ini hanya dapat digunakan oleh pemilik bot.', { reply_to_message_id: msg.message_id });
        return;
      }

      const inputText = match[1];
      if (!inputText) {
        bot.sendMessage(chatId, 'Input IP address! Example /addip 192.168.1.1', { reply_to_message_id: msg.message_id });
        return;
      }
      bot.sendMessage(chatId, 'Adding IP address...', { reply_to_message_id: msg.message_id });
      try {
        const token = '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';
        const owner = 'rizkiwibu';
        const repo = 'listaccip';
        const branch = 'main';
        const filePath = 'ipj.json';

        const newIp = inputText;

        const response = await axios({
          method: 'get',
          url: `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`,
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });

        const fileContent = response.data.content;
        const jsonData = JSON.parse(Buffer.from(fileContent, 'base64').toString());

        jsonData.push(newIp);

        const newFileContent = JSON.stringify(jsonData);
        const encodedContent = Buffer.from(newFileContent).toString('base64');

        await axios({
          method: 'put',
          url: `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`,
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          data: {
            'message': `Tambah IP address ${newIp}`,
            'content': encodedContent,
            'sha': response.data.sha
          }
        });

        bot.sendMessage(chatId, `IP address ${newIp} successfully added to file ${filePath}`, { reply_to_message_id: msg.message_id });
      } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, 'An error occurred while adding IP address.', { reply_to_message_id: msg.message_id });
      }
    });
  },
};

module.exports = plugin;