const plugin = {
  commands: ['/addbot'],
  tags: ['admin'],
  init: async (bot, { usedPrefix }) => {
    bot.onText(/^\/addbot$/, async (msg) => {
      const chatId = msg.chat.id;
      const link = `https://t.me/IKYOFFICIAL_BOT?startgroup=true`;
      try {
        bot.sendMessage(chatId, `Klik link berikut untuk menambahkan bot ke grup: ${link}`, {
          reply_to_message_id: msg.message_id,
        });
      } catch (e) {
        bot.sendMessage(chatId, `Error: ${e.message}`, {
          reply_to_message_id: msg.message_id,
        });
      }
    });
  },
};

module.exports = plugin;