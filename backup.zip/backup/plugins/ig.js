const fetch = require('node-fetch');

const Func = {
  isUrl: (str) => {
    const regex = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:\d+)?(\/|\/(\w|\.|-|_)+(\/\w|\.|-|_)*)?\/?(\?\S+)?/;
    return regex.test(str);
  },
};

const plugin = {
  commands: ['/igdl'],
  tags: ['downloader'],
  init: async (bot, { usedPrefix }) => {
    bot.onText(/^\/igdl$/, async (msg) => {
      const chatId = msg.chat.id;
      bot.sendMessage(chatId, 'Input URL Instagram yang ingin diunduh!', {
        reply_to_message_id: msg.message_id,
      });
    });

    bot.onText(/^\/igdl (.+)$/, async (msg, match) => {
      const text = match[1];
      if (!Func.isUrl(text))
        throw `*• Example :* ${usedPrefix + 'igdl'} *[Instagram url]*\n\n*• Cara penggunaan :*\n1. Ketik /igdl\n2. Masukkan URL Instagram yang ingin diunduh\n3. Tunggu proses pengunduhan selesai`;
      bot.sendMessage(msg.chat.id, 'Tunggu sebentar...', {
        reply_to_message_id: msg.message_id,
      });
      try {
        let media = await fetch(
          'https://widipe.com/download/igdl?url=' + text,
        );
        let data = await media.json();
        if (data.length === 0) throw '*[ NO MEDIA FOUND ]*';
        for (let i of data.result) {
          bot.sendMessage(msg.chat.id, '*[ INSTAGRAM DOWNLOADER ]*', {
            reply_to_message_id: msg.message_id,
          });
          bot.sendMessage(msg.chat.id, i.url, {
            reply_to_message_id: msg.message_id,
          });
        }
      } catch (e) {
        bot.sendMessage(msg.chat.id, 'Error: ' + e, {
          reply_to_message_id: msg.message_id,
        });
      }
    });
  },
};

module.exports = plugin;