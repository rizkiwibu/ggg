const wordGuessingPlugin = {
  commands: ['/tebakkata'],
  tags: ['game'],
  init: async (bot) => {
    const words = ['telepon', 'komputer', 'bot', 'programming'];
    const randomWord = words[Math.floor(Math.random() * words.length)];
    const guessedLetters = new Set();
    let attempts = 6; // Jumlah percobaan

    bot.onText(/\/tebakkata/, (msg) => {
      const chatId = msg.chat.id;
      bot.sendMessage(chatId, 'Saya telah memilih sebuah kata. Coba tebak hurufnya!');

      const displayWord = () => {
        return randomWord.split('').map(letter => (guessedLetters.has(letter) ? letter : '_')).join(' ');
      };

      const guessHandler = (msg) => {
        const userGuess = msg.text.toLowerCase();
        if(userGuess.length !== 1) {
          bot.sendMessage(chatId, 'Tolong masukkan huruf tunggal!');
          return;
        }

        if (guessedLetters.has(userGuess)) {
          bot.sendMessage(chatId, 'Huruf ini telah ditebak sebelumnya!');
          return;
        }

        guessedLetters.add(userGuess);

        if (randomWord.includes(userGuess)) {
          bot.sendMessage(chatId, `Huruf ${userGuess} ada dalam kata!`);
        } else {
          attempts--;
          bot.sendMessage(chatId, `Huruf ${userGuess} tidak ada dalam kata. Anda memiliki ${attempts} percobaan lagi.`);
        }

        bot.sendMessage(chatId, `Kata: ${displayWord()}`);

        if (attempts === 0) {
          bot.sendMessage(chatId, `Anda gagal! Kata yang benar adalah: ${randomWord}`);
          bot.removeListener('message', guessHandler); // Menghentikan pendengar setelah gagal
        } else if (displayWord() === randomWord) {
          bot.sendMessage(chatId, `Selamat! Anda berhasil menebak kata ${randomWord}.`);
          bot.removeListener('message', guessHandler); // Menghentikan pendengar setelah menang
        }
      };

      bot.on('message', guessHandler); // Menambahkan pendengar untuk tebakan
    });
  },
};

module.exports = wordGuessingPlugin;