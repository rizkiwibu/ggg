const fetch = require('node-fetch');

const plugin = {
  commands: ['/animeupdate'],
  tags: ['anime'],
  init: async (bot, { buttonUrl, mess }) => {
    bot.onText(/^\/animeupdate$/, async (msg) => {
      const chatId = msg.chat.id;
      bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });
      try {
        const response = await fetch('https://api.jikan.moe/v4/seasons/now?filter=tv');
        const data = await response.json();
        const arr = [];
        for (let a of data.data) {
          arr.push([
            `*• Title :* ${a.title}
*• Genre :* *[ ${a.genres.map((a) => a.name).join(", ")} ]*
*• Type :* ${a.type}
*• Season :* ${a.season} *[ ${a.year} ]*
*• Source :* ${a.source}
*• Total episode :* ${a.episodes}
*• Status :* ${a.status}
*• Duration :* ${a.duration}
*• Studio :* *[ ${a.studios.map((a) => a.name).join(", ")} ]*
*• Rating :* ${a.rating}
*• Score :* ${a.score}/10.0
*• Popularity :* ${a.popularity}`,
            null,
            a.images.jpg.large_image_url,
            [],
            null,
            [["Watch Trailer !", a.trailer.url]],
          ]);
        }
        const media = arr.map((a) => ({
          type: "photo",
          media: a[2],
          caption: a[0],
        }));
        const chunkSize = 10;
        const chunks = [];

        for (let i = 0; i < media.length; i += chunkSize) {
          chunks.push(media.slice(i, i + chunkSize));
        }

        chunks.forEach((chunk, index) => {
          setTimeout(() => {
            bot.sendMediaGroup(chatId, chunk, {
              reply_to_message_id: msg.message_id,
            });
          }, index * 1000); // delay 1 detik antara pengiriman pesan-pesan
        });
      } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, 'An error occurred while processing your request.', { reply_to_message_id: msg.message_id });
      }
    });
  },
};

module.exports = plugin;