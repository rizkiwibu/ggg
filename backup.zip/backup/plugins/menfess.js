const plugin = {
  commands: ['/menfess', '/reply', '/getid', '/help'],
  tags: ['anonymous'],
  userMessages: {}, // Menyimpan pesan anonim untuk setiap pengguna
  init: (bot) => {
    // Menangani perintah /menfess
    bot.onText(/^\/menfess(?:\s+(\d+))? (.+)$/, async (msg, match) => {
      const chatId = msg.chat.id;
      const targetUserId = match[1]; // ID pengguna yang dituju
      const messageText = match[2]; // Pesan yang akan dikirim

      // Jika ID pengguna tidak diberikan
      if (!targetUserId) {
        bot.sendMessage(chatId, 'Input ID pengguna dan pesan! Contoh penggunaan: /menfess <ID_pengguna> <pesan>\n\nContoh: /menfess 123456789 Halo, ini pesan anonim!', { reply_to_message_id: msg.message_id });
        return;
      }

      // Kirim pesan anonim ke pengguna yang dituju
      try {
        await bot.sendMessage(targetUserId, `Pesan anonim: ${messageText}`);
        
        // Simpan pesan untuk pengguna yang dituju
        if (!plugin.userMessages[targetUserId]) {
          plugin.userMessages[targetUserId] = [];
        }
        plugin.userMessages[targetUserId].push({ from: chatId, message: messageText });

        bot.sendMessage(chatId, 'Pesan Anda telah dikirim!', { reply_to_message_id: msg.message_id });
      } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, 'Gagal mengirim pesan. Pastikan ID pengguna benar dan bot dapat menghubungi mereka.', { reply_to_message_id: msg.message_id });
      }
    });

    // Menangani perintah /reply
    bot.onText(/^\/reply (.+)$/, async (msg, match) => {
      const chatId = msg.chat.id;
      const replyText = match[1]; // Pesan balasan

      // Cek apakah pengguna memiliki pesan yang bisa dibalas
      if (!plugin.userMessages[chatId] || plugin.userMessages[chatId].length === 0) {
        bot.sendMessage(chatId, 'Anda tidak memiliki pesan untuk dibalas.', { reply_to_message_id: msg.message_id });
        return;
      }

      // Ambil pesan terakhir yang diterima
      const lastMessage = plugin.userMessages[chatId].pop();
      const targetUserId = lastMessage.from; // ID pengguna yang mengirim pesan anonim

      // Kirim balasan ke pengguna yang mengirim pesan anonim
      try {
        await bot.sendMessage(targetUserId, `Balasan anonim: ${replyText}`);
        bot.sendMessage(chatId, 'Balasan Anda telah dikirim!', { reply_to_message_id: msg.message_id });
      } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, 'Gagal mengirim balasan. Pastikan pengguna dapat dihubungi.', { reply_to_message_id: msg.message_id });
      }
    });

    // Menangani perintah /getid
    bot.onText(/^\/getid$/, async (msg) => {
      const chatId = msg.chat.id;
      const userId = msg.from.id; // ID pengguna yang mengirim perintah
      const currentChatId = chatId; // ID chat saat ini

      // Mengirimkan ID pengguna dan ID chat
      bot.sendMessage(chatId, `Your user ID: ${userId}\nCurrent chat ID: ${currentChatId}`, { reply_to_message_id: msg.message_id });
    });

    // Menambahkan instruksi penggunaan untuk perintah /help
    bot.onText(/^\/help$/, (msg) => {
      const chatId = msg.chat.id;
      bot.sendMessage(chatId, 
        "Cara menggunakan:\n" +
        "1. /menfess <ID_pengguna> <pesan> - Mengirim pesan anonim ke pengguna yang dituju.\n" +
        "2. /reply <pesan> - Membalas pesan anonim yang diterima.\n" +
        "3. /getid - Mendapatkan ID pengguna dan ID chat.\n" +
        "4. /help - Menampilkan instruksi penggunaan bot ini.", 
        { reply_to_message_id: msg.message_id });
    });
  }
};

module.exports = plugin;