const axios = require('axios');
const os = require('os');

const plugin = {
  commands: ['/server'],
  tags: ['info'],
  init: async (bot, { buttonUrl, mess, api, apikey }) => {
    bot.onText(/^\/server$/, async (msg) => {
      const chatId = msg.chat.id;
      try {
        const response = await axios.get('http://ip-api.com/json/');
        const serverInfo = response.data;

        bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });
        let serverMessage = `•  *S E R V E R*\n\n`;
        const osInfo = os.platform();
        const totalRAM = Math.floor(os.totalmem() / (1024 * 1024));
        const freeRAM = Math.floor(os.freemem() / (1024 * 1024));
        const uptime = os.uptime();
        const uptimeFormatted = formatUptime(uptime);
        const processor = os.cpus()[0].model;

        serverMessage += `┌  ◦  OS : ${osInfo}\n`;
        serverMessage += `│  ◦  RAM : ${freeRAM} MB / ${totalRAM} MB\n`;
        serverMessage += `│  ◦  Country : ${serverInfo.country}\n`;
        serverMessage += `│  ◦  CountryCode : ${serverInfo.countryCode}\n`;
        serverMessage += `│  ◦  Region : ${serverInfo.region}\n`;
        serverMessage += `│  ◦  RegionName : ${serverInfo.regionName}\n`;
        serverMessage += `│  ◦  City : ${serverInfo.city}\n`;
        serverMessage += `│  ◦  Zip : ${serverInfo.zip}\n`;
        serverMessage += `│  ◦  Lat : ${serverInfo.lat}\n`;
        serverMessage += `│  ◦  Lon : ${serverInfo.lon}\n`;
        serverMessage += `│  ◦  Timezone : ${serverInfo.timezone}\n`;
        serverMessage += `│  ◦  ISP : ${serverInfo.isp}\n`;
        serverMessage += `│  ◦  Org : ${serverInfo.org}\n`;
        serverMessage += `│  ◦  AS : ${serverInfo.as}\n`;
        serverMessage += `│  ◦  Query : HIDDEN\n`;
        serverMessage += `│  ◦  Uptime : ${uptimeFormatted}\n`;
        serverMessage += `└  ◦  Processor : ${processor}`;

        const replyMarkup = {
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Script Bot', url: buttonUrl }],
            ],
          },
        };

        bot.sendMessage(chatId, serverMessage, { reply_to_message_id: msg.message_id, ...replyMarkup });
      } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, 'An error occurred while processing your request.', { reply_to_message_id: msg.message_id });
      }
    });
  },
};

function formatUptime(uptime) {
  let seconds = Math.floor(uptime % 60);
  let minutes = Math.floor((uptime / 60) % 60);
  let hours = Math.floor((uptime / (60 * 60)) % 24);
  let days = Math.floor(uptime / (60 * 60 * 24));

  let formattedUptime = '';
  if (days > 0) formattedUptime += `${days} days `;
  if (hours > 0) formattedUptime += `${hours} hours `;
  if (minutes > 0) formattedUptime += `${minutes} minutes `;
  if (seconds > 0) formattedUptime += `${seconds} seconds`;

  return formattedUptime.trim();
}

module.exports = plugin;