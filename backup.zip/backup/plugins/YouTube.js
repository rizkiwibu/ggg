const { Youtube } = require('@neoxr/youtube-scraper');

const plugin = {
  commands: ['/lagu'],
  tags: ['music'],
  init: async (bot, { buttonUrl, mess, api, apikey }) => {
    bot.onText(/^\/lagu(?: (.+))?$/, async (msg, match) => {
      const chatId = msg.chat.id;
      const inputText = match[1];
      if (!inputText) {
        bot.sendMessage(chatId, 'Input judul lagu! Example /lagu lagu terbaru', { reply_to_message_id: msg.message_id });
        return;
      }
      bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });
      try {
        const yt = new Youtube();
        const result = await yt.play(inputText);

        const { title, channel, duration, views, publish, data } = result;

        const caption = `Title: ${title}\nChannel: ${channel}\nDuration: ${duration}\nViews: ${views}\nPublish: ${publish}`;
        const replyMarkup = {
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Script Bot', url: buttonUrl }],
            ],
          },
        };

        bot.sendAudio(chatId, data.url, { caption: caption, reply_to_message_id: msg.message_id, ...replyMarkup });
      } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, 'An error occurred while processing your request.', { reply_to_message_id: msg.message_id });
      }
    });
  },
};

module.exports = plugin;