const axios = require('axios');
const cheerio = require('cheerio');
const _ = require('lodash');
const cycle = require('cycle');


class Samehada {
  /**
   * Mengambil data anime terbaru dari API
   * @returns {Promise<Array<Object>>}
   */
  async latest() {
    try {
      const response = await axios.get("https://samehadaku.email/anime-terbaru/");
      const $ = cheerio.load(response.data);
      const posts = [];
      $(".post-show li").each((index, element) => {
        const title = $(element).find(".entry-title a").attr("title");
        const link = $(element).find(".entry-title a").attr("href");
        const author = $(element).find('[itemprop="author"] author').text();
        const date = $(element)
          .find(".dashicons-calendar")
          .parent()
          .text()
          .replace("Released on:", "")
          .trim();
        posts.push({
          title,
          author,
          date,
          link,
        });
      });
      return posts;
    } catch (error) {
      console.error(error);
      return [];
    }
  }

  /**
   * Mencari anime berdasarkan keyword
   * @param {string} text
   * @returns {Promise<Array<Object>>}
   */
  async search(text) {
    if (!text) {
      throw new Error("Keyword tidak boleh kosong");
    }
    try {
      const response = await axios.get("https://samehadaku.email");
      const $ = cheerio.load(response.data);
      const scriptContent = $("#live_search-js-extra").html();
      const nonceMatch = scriptContent.match(/"nonce":"([^"]+)"/);
      const nonce = nonceMatch ? nonceMatch[1] : null;

      const responseSearch = await axios.get(
        `https://samehadaku.email/wp-json/eastheme/search/?keyword=${text}&nonce=${nonce}`,
      );
      const result = Object.values(responseSearch.data).map((v) => v);
      return result;
    } catch (error) {
      console.error(error);
      return [];
    }
  }

  /**
   * Mengambil detail anime
   * @param {string} url
   * @returns {Promise<Object>}
   */
  async detail(url) {
    if (!url) {
      throw new Error("URL tidak boleh kosong");
    }
    try {
      const response = await axios.get(url);
      const $ = cheerio.load(response.data);

      const title = $("h1.entry-title").text().trim();
      const author = "shannz";
      const image = $(".thumb img").attr("src");
      const rating = $('.rtg span[itemprop="ratingValue"]').text().trim();
      const description = $(".entry-content-single").text().trim();

      const genres = [];
      $(".genre-info a").each((i, el) => {
        genres.push($(el).text().trim());
      });

      const episodes = [];
      $(".lstepsiode.listeps li").each((i, el) => {
        const episodeNumber = $(el).find(".epsright .eps a").text().trim();
        const episodeTitle = $(el).find(".epsleft .lchx a").text().trim();
        const episodeUrl = $(el).find(".epsleft .lchx a").attr("href");
        const episodeDate = $(el).find(".epsleft .date").text().trim();

        episodes.push({
          number: episodeNumber,
          title: episodeTitle,
          url: episodeUrl,
          date: episodeDate,
        });
      });

      return {
        author,
        title,
        image,
        rating,
        description,
        genres,
        episodes,
      };
    } catch (error) {
      console.error(error);
      return null;
    }
  }

  /**
   * Mengunduh anime
   * @param {string} url
   * @returns {Promise<Object>}
   */
  async download(url) {
    if (!url.includes("samehadaku.email")) {
      throw new Error("URL tidak valid");
    }
    try {
      const response = await axios.get(url);
      const $ = cheerio.load(response.data);
      const result = {
        judul: $("h1.entry-title").text().trim(),
        url: url,
        unduhan: [], // Fix typo
      };

      const serverList = $("div#server > ul > li");

      for (let i = 0; i < serverList.length; i++) {
        const server = $(serverList[i]);
        const serverInfo = {
          nama: server.find("span").text().trim(),
          tipeServer: server.find("div").attr("data-type"),
          nomorServer: server.find("div").attr("data-nume"),
          postId: server.find("div").attr("data-post"),
        };

        const formData = new URLSearchParams();
        formData.append("action", "player_ajax");
        formData.append("post", serverInfo.postId);
        formData.append("nume", serverInfo.nomorServer);
        formData.append("type", serverInfo.tipeServer);

        const linkResponse = await axios.post(
          "https://samehadaku.email/wp-admin/admin-ajax.php",
          formData,
          {
            headers: {
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
              Origin: "https://samehadaku.email",
              "Content-Type": "application/x-www-form-urlencoded",
            },
          },
        );

        const $link = cheerio.load(linkResponse.data);
        serverInfo.tautan = $link("iframe").attr("src");

        result.unduhan.push(serverInfo);
      }

      return result;
    } catch (error) {
      console.error(error);
      throw error;
    }
  }
}

const plugin = {
  commands: ['/samehadaku'],
  tags: ['anime'],
  init: async (bot, { buttonUrl, mess, api, apikey }) => {
    bot.onText(/^\/samehadaku(?: (.+))?$/, async (msg, match) => {
      const chatId = msg.chat.id;
      const inputText = match[1];
      if (!inputText) {
        bot.sendMessage(chatId, `*[ SHINIGAMI EXAMPLE ]*
> *• Example :* /samehadaku search *[query]*
> *• Example :* /samehadaku detail *[url]*
> *• Example :* /samehadaku episode *[url]*`, { reply_to_message_id: msg.message_id });
        return;
      }
      bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });
      try {
        let samehada = new Samehada();
        if ("search" === inputText.split(" ")[0]) {
          if (!inputText.split(" ")[1]) {
            throw `*• Example :* /samehadaku search *[query]*`;
          }
          let res = await samehada.search(inputText.split(" ")[1]);
          let cap =
            `Type a command
/samehadaku detail *[url]* for Get detail!\n\n` +
            res
              .map(
                (a, i) => `*${i + 1}.* ${a.title}
*• Url :* ${a.url}`,
              )
              .join("\n\n");
          bot.sendMessage(chatId, cap, { reply_to_message_id: msg.message_id });
        } else if ("detail" === inputText.split(" ")[0]) {
          if (!inputText.split(" ")[1]) {
            throw `*• Example :* /samehadaku detail *[url]*`;
          }
          let resl = await samehada.detail(inputText.split(" ")[1]);
          let cap = `*${resl.title}*
*• Score :* ${resl.rating}
*• Genre :* ${resl.genres.join(", ")}
${resl.description || ""}

Type a command
/samehadaku episode *[url]* for Get video!
 
${resl.episodes
  .map(
    (a) => `*• Title :* ${a.title}
*• Date :* ${a.date}
*• Url :* ${a.url}`,
  )
  .join("\n\n")}`;
          if (cap.length > 1024) {
            let potongan = cap.substring(0, 1024);
            let sisa = cap.substring(1024);
            await bot.sendPhoto(chatId, resl.image, { caption: potongan, reply_to_message_id: msg.message_id });
            await bot.sendMessage(chatId, sisa, { reply_to_message_id: msg.message_id });
          } else {
            await bot.sendPhoto(chatId, resl.image, { caption: cap, reply_to_message_id: msg.message_id });
          }
        } else if ("episode" === inputText.split(" ")[0]) {
          if (!inputText.split(" ")[1]) {
            throw `*• Example :* /samehadaku episode *[url]*`;
          }
          let buff = await samehada.download(inputText.split(" ")[1]);
          const cyclicRefs = cycle.detect(buff);
          if (cyclicRefs.length > 0) {
            console.error('Cyclic references detected:', cyclicRefs);
            throw new Error('Cyclic object value');
          }
          buff = _.cloneDeep(buff);
          let hasil = buff.unduhan.find((a) => a.tautan.endsWith(".mp4"));
          let teks = `*• Title :* ${buff.judul}\n*• Url :* ${buff.url}\n*• Resolution :* ${hasil.nama}\n*• Download :* ${hasil.tautan}`;
          if (teks.length > 0) {
            if (teks.length > 1024) {
              let potongan = teks.substring(0, 1024);
              let sisa = teks.substring(1024);
              if (potongan) {
                let q = await bot.sendMessage(chatId, {
                  text: potongan,
                });
                await bot.sendDocument(chatId, hasil.tautan, { caption: buff.utl, fileName: buff.judul + ".mp4", mimetype: "video/mp4" }, { quoted: q });
              }
              if (sisa) {
                await bot.sendMessage(chatId, sisa, { reply_to_message_id: msg.message_id });
              }
            } else {
              if (teks) {
                let q = await bot.sendMessage(chatId, {
                  text : teks,
                });
                await bot.sendDocument(chatId, hasil.tautan, { caption: buff.utl, fileName: buff.judul + ".mp4", mimetype: "video/mp4" }, { quoted: q });
              }
            }
          }
        } else {
          throw `*• Example :* /samehadaku search *[query]*
> *• Example :* /samehadaku detail *[url]*
> *• Example :* /samehadaku episode *[url]*`;
        }
      } catch (err) {
        bot.sendMessage(chatId, err.toString(), { reply_to_message_id: msg.message_id });
      }
    });
  },
};

module.exports = plugin;