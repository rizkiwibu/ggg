const axios = require('axios');

const plugin = {
  commands: ['/blackbox'],
  tags: ['ai'],
  init: async (bot, { buttonUrl, mess, api, apikey }) => {
    bot.onText(/^\/blackbox(?: (.+))?$/, async (msg, match) => {
      const chatId = msg.chat.id;
      const inputText = match[1];
      if (!inputText) {
        bot.sendMessage(chatId, 'Input Text! Example /blackbox Hello', { reply_to_message_id: msg.message_id });
        return;
      }
      bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });
      try {
        const id = inputText.split("@")[0];
        const json = {
          messages: [{ id: id, content: inputText, role: "user" }],
          id: id,
          previewToken: null,
          userId: "4d112c20-3201-46a5-afc6-6b308d98a450",
          codeModelMode: true,
          agentMode: {},
          trendingAgentMode: {},
          isMicMode: false,
          isChromeExt: false,
          githubToken: null,
        };

        const { data } = await axios.post("https://www.blackbox.ai/api/chat", json);
        
        // Cleaning the data
        let cleanedData = data.replace(/[^a-zA-Z0-9().\s]/g, "");
        cleanedData = cleanedData.replace(/^.*?(\b\w+\b|\b\d+\b)\s*/, "");
        cleanedData = cleanedData.replace(/(\s\s+).*(\s\s+)$/g, "");
        
        const caption = `Blackbox Response: ${cleanedData}`;
        const replyMarkup = {
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Script Bot', url: buttonUrl }],
            ],
          },
        };

        bot.sendMessage(chatId, caption, { reply_to_message_id: msg.message_id, ...replyMarkup });
      } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, 'An error occurred while processing your request.', { reply_to_message_id: msg.message_id });
      }
    });
  },
};

module.exports = plugin;