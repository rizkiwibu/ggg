const fetch = require('node-fetch');
const cheerio = require('cheerio');

const plugin = {
  commands: ['/hentai'],
  tags: ['hentai'],
  init: async (bot, { buttonUrl, mess, api, apikey }) => {
    bot.onText(/^\/hentai(?: (.+))?$/, async (msg, match) => {
      const chatId = msg.chat.id;
      const inputText = match[1];
      if (!inputText) {
        bot.sendMessage(chatId, 'Input a number to select a hentai video! Example /hentai 1', { reply_to_message_id: msg.message_id });
        return;
      }
      bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });
      try {
        const list = await getHentaiList();
        const selectedIndex = parseInt(inputText) - 1;
        if (selectedIndex < 0 || selectedIndex >= list.length) {
          bot.sendMessage(chatId, 'Invalid video number!', { reply_to_message_id: msg.message_id });
          return;
        }
        const selectedVideo = list[selectedIndex];
        const caption = getCaption(selectedVideo);
        const replyMarkup = {
          reply_markup: {
            inline_keyboard: [
              [{ text: 'More Hentai', url: buttonUrl }],
            ],
          },
        };

        bot.sendVideo(chatId, selectedVideo.video_1 || selectedVideo.video_2, { caption: caption, reply_to_message_id: msg.message_id, ...replyMarkup });
      } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, 'An error occurred while processing your request.', { reply_to_message_id: msg.message_id });
      }
    });

    // Move the new code here
    bot.onText(/^\/hentai$/, async (msg) => {
      const chatId = msg.chat.id;
      const list = await getHentaiList();
      const teks = list
        .slice(0, 9)
        .map((obj, index) => `*${index + 1}.* ${obj.title}`)
        .join("\n");
      bot.sendMessage(chatId, `*[ HENTAI LIST ]*\n${teks}\n\n*Input Number from 1 to 9 to get video*`, { reply_to_message_id: msg.message_id });
    });
  },
};

async function getHentaiList() {
  const page = Math.floor(Math.random() * 1153);
  const response = await fetch(`https://sfmcompile.club/page/${page}`);
  const htmlText = await response.text();
  const $ = cheerio.load(htmlText);

  const list = [];
  $("#primary > div > div > ul > li > article").each(function (a, b) {
    list.push({
      title: $(b).find("header > h2").text(),
      link: $(b).find("header > h2 > a").attr("href"),
      category: $(b)
        .find("header > div.entry-before-title > span > span")
        .text()
        .replace("in ", ""),
      share_count: $(b)
        .find("header > div.entry-after-title > p > span.entry-shares")
        .text(),
      views_count: $(b)
        .find("header > div.entry-after-title > p > span.entry-views")
        .text(),
      type: $(b).find("source").attr("type") || "image/jpeg",
      video_1:
        $(b).find("source").attr("src") || $(b).find("img").attr("data-src"),
      video_2: $(b).find("video > a").attr("href") || "",
    });
  });

  return list;
}

function getCaption(obj) {
  return `*Title:* ${obj.title}\n*Link:* ${obj.link}\n*Category:* ${obj.category}\n*Share Count:* ${obj.share_count}\n*Views Count:* ${obj.views_count}\n*Type:* ${obj.type}`;
}

module.exports = plugin;