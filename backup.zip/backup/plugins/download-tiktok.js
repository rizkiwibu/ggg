const fetch = require('node-fetch');

const plugin = {
  commands: ['/tiktok'],
  tags: ['download'],
  init: async (bot, { buttonUrl, mess }) => {
    bot.onText(/^\/tiktok(?: (.+))?$/, async (msg, match) => {
      const chatId = msg.chat.id;
      const inputText = match[1];

      // Validasi input
      if (!inputText) {
        bot.sendMessage(chatId, 'Input Link! Example /tiktok https://vm.tiktok.com/ZGJAmhSrp/', { reply_to_message_id: msg.message_id });
        return;
      }

      // Mengirim pesan menunggu
      bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });

      try {
        // Mengambil data dari API
        const apis = await fetch(`https://widipe.com/download/tiktokdl?url=${encodeURIComponent(inputText)}`);
        const res = await apis.json();

        // Log respons API
        console.log('API Response:', res);

        // Memeriksa apakah data yang diharapkan ada
        if (!res.result || !res.result.video) {
          bot.sendMessage(chatId, 'Video tidak ditemukan atau link tidak valid.', { reply_to_message_id: msg.message_id });
          return;
        }

        // Mendapatkan informasi video
        const videoUrl = res.result.video; // Link video tanpa watermark
        const audioUrl = res.result.music; // Link audio (jika diperlukan)

        // Menyusun caption untuk video
        const caption = `*Video berhasil diunduh!*\n*Link Video:* [Download Video](${videoUrl})\n*Link Audio:* [Download Audio](${audioUrl})`;

        // Menyusun markup untuk tombol
        const replyMarkup = {
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Script Bot', url: buttonUrl }],
              [{ text: 'Audio', url: audioUrl }],
            ],
          },
        };

        // Mengirim video tanpa watermark
        bot.sendVideo(chatId, videoUrl, { caption: caption, parse_mode: 'Markdown', reply_to_message_id: msg.message_id, ...replyMarkup });
      } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, 'An error occurred while processing your request.', { reply_to_message_id: msg.message_id });
      }
    });
  },
};

module.exports = plugin;