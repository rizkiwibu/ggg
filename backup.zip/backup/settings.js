

module.exports = {
  ownerUsernames: ["Ikystoreofficial"],//Your Username
  ownerNumber: "6285878836361",//Your Number 
  botusername: ["IKYOFFICIAL_BOT"],//Your Username bot
  telegramBotToken: "6864141116:AAH8iTVPFwh0vBmn0ZNFl7kbAdB95bLutBM",//Your Bot Tokens
  imageUrl: "https://files.catbox.moe/i10z6d.jpg",//Thumbnail Url
  buttonUrl: "https://github.com/rizkiwibu",//Script Url
  api: "https://api.betabotz.eu.org",
  apikey: "btzirfanwibu88",//Change Your Apikey
  mess: {
    eror: "Internal Server Eror 😵",
    owner: "Sorry, this command can only be accessed by the owner!",
    group: "Sorry, this command can only be used within a group!",
    wait: "Your request is being processed...",
  },
};
